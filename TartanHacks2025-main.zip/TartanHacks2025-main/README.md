# LiquidLabyrith

## Underwater Escape Room Mini-Game

## Need Pygame and google.generativeai to run:
```
pip install pygame
pip install -q -U google-generativeai
```
